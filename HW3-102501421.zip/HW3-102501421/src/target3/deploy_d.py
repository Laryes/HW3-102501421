"""HW3 D: affinity first, least-loaded overflow when primary is at capacity.

Run on the Linux GPU instance; the four SGLang servers must already be up.
"""
import asyncio
import argparse
import json
import logging
import os
from pathlib import Path

os.environ["RAY_SERVE_SESSION_ID_HEADER_KEY"] = "x-session-id"

import aiohttp
import ray
from ray import serve
from ray.serve.config import RequestRouterConfig
from ray.serve.experimental.consistent_hash_router import ConsistentHashRouter
from ray.cluster_utils import Cluster
from starlette.responses import JSONResponse, StreamingResponse


class AffinityOverflowRouter(ConsistentHashRouter):
    """Extend C with a second rank containing all non-primary replicas.

    Ray 2.56's selector attempts each rank in order, accepting a replica
    only below its max_ongoing_requests. In the fallback rank, it picks
    the lowest observed queue length using Ray's cache/probes. Live
    admission checks can reject a stale choice, causing another retry.
    Only the current request session ID and current replica state are used.
    """

    def initialize_state(self, **kwargs):
        # Keep the parent's first rank strictly affinity-only. We implement
        # fallback ourselves as one group, instead of ordered ring successors.
        super().initialize_state(
            num_virtual_nodes=kwargs.get("num_virtual_nodes", 100),
            num_fallback_replicas=0,
        )
        logging.getLogger("ray.serve").info(
            "AffinityOverflowRouter ready: affinity primary, then "
            "least-loaded other replicas; capacity threshold=max_ongoing_requests"
        )

    async def choose_replicas(self, candidate_replicas, pending_request=None):
        ranks = await super().choose_replicas(candidate_replicas, pending_request)
        if not ranks or pending_request is None:
            return ranks
        # The parent's strict-affinity rank has one primary replica.
        primary_ids = {replica.replica_id for replica in ranks[0]}
        alternatives = [replica for replica in candidate_replicas
                        if replica.replica_id not in primary_ids]
        return ranks + [alternatives] if alternatives else ranks


@serve.deployment(
    num_replicas=4,
    max_ongoing_requests=16,
    request_router_config=RequestRouterConfig(
        request_router_class=AffinityOverflowRouter,
        request_router_kwargs={"num_virtual_nodes": 100},
    ),
    max_replicas_per_node=1,
    ray_actor_options={"num_cpus": 1, "num_gpus": 0},
)
class BackendProxy:
    def __init__(self):
        self.node_id = str(ray.get_runtime_context().get_node_id())
        node = next(n for n in ray.nodes() if n["NodeID"] == self.node_id)
        indices = [i for i in range(4) if node["Resources"].get(f"backend_{i}", 0)]
        if len(indices) != 1:
            raise RuntimeError(f"Replica must be on a tagged worker: {node}")
        self.backend = f"http://127.0.0.1:{30000 + indices[0]}"
        self.replica_id = str(serve.get_replica_context().replica_id)
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=600),
            connector=aiohttp.TCPConnector(limit=0),
            auto_decompress=False,
        )

    async def __call__(self, request):
        headers = {
            "X-Ray-Replica-ID": self.replica_id,
            "X-Ray-Node-ID": self.node_id,
            "X-SGLang-Backend": self.backend,
        }
        if request.method != "POST" or request.url.path != "/generate":
            return JSONResponse({"error": "Use POST /generate"}, status_code=404,
                                headers=headers)
        forwarded = {k: request.headers[k] for k in
                     ("X-Session-Id", "X-Workload-Request-ID", "X-Prefix-Family")
                     if k in request.headers}
        forwarded["Content-Type"] = "application/json"
        forwarded["Accept-Encoding"] = "identity"
        try:
            response = await self.session.post(
                self.backend + "/generate", data=await request.body(),
                headers=forwarded,
            )
        except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=502, headers=headers)
        if response.status != 200:
            try:
                detail = await response.text()
            finally:
                response.release()
            return JSONResponse({"backend_error": detail},
                                status_code=response.status, headers=headers)

        async def stream():
            try:
                async for chunk in response.content.iter_any():
                    yield chunk
            finally:
                response.close()

        headers["Cache-Control"] = "no-cache"
        return StreamingResponse(stream(), media_type="text/event-stream",
                                 headers=headers)

    async def __del__(self):
        if hasattr(self, "session"):
            await self.session.close()


async def main(max_ongoing_requests=16, run_label="D"):
    cluster = Cluster()
    initialized = False
    try:
        # No CPU on head: the four 1-CPU replicas can only use workers.
        cluster.add_node(num_cpus=0, num_gpus=0,
                         object_store_memory=100 * 1024 * 1024)
        for i in range(4):
            cluster.add_node(num_cpus=2, num_gpus=0,
                             resources={f"backend_{i}": 1},
                             object_store_memory=100 * 1024 * 1024)
        cluster.wait_for_nodes()
        ray.init(address=cluster.address)
        initialized = True
        nodes = [n for n in ray.nodes() if n["Alive"]]
        if len(nodes) != 5:
            raise RuntimeError(f"Expected 5 active nodes, got {len(nodes)}")
        Path("logs").mkdir(exist_ok=True)
        Path(f"logs/ray-topology-{run_label}.json").write_text(
            json.dumps(nodes, indent=2), encoding="utf-8")
        serve.start(http_options={"host": "127.0.0.1", "port": 8000,
                                  "location": "HeadOnly"})
        application = BackendProxy.options(
            max_ongoing_requests=max_ongoing_requests).bind()
        serve.run(application, name="routing", route_prefix="/")
        print(f"{run_label} READY: POST http://127.0.0.1:8000/generate "
              f"max_ongoing_requests={max_ongoing_requests}", flush=True)
        while True:
            await asyncio.sleep(1)
    finally:
        if initialized:
            serve.shutdown()
            ray.shutdown()
        cluster.shutdown()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-ongoing-requests", type=int, choices=[16], default=16)
    parser.add_argument("--run-label", choices=["D"], default="D")
    args = parser.parse_args()
    if args.max_ongoing_requests <= 0:
        parser.error("--max-ongoing-requests must be positive")
    try:
        asyncio.run(main(args.max_ongoing_requests, args.run_label))
    except KeyboardInterrupt:
        pass
