# 第三次挑战提交数据索引

本目录按任务书的 `results/target1/` 与 `results/target3/` 结构整理。原始文件采用复制方式归档，CSV、JSON 和日志内容均未修改。模型权重、虚拟环境、安装包、缓存目录和过期 PID 文件不在本目录中。

## 目录结构

```text
HW3-102501421/
└── results/
    ├── README.md
    ├── target1/
    │   ├── shared_prefix/
    │   ├── dispersed_prefix/
    │   └── 配置、环境、验证及对照文件
    └── target3/
        ├── A_default/run-1、run-2、run-3/
        ├── B_candidates/
        │   ├── candidate-16/run-1、run-2、run-3/
        │   └── candidate-64/run-1、run-2、run-3/
        ├── C_affinity/run-1、run-2、run-3/
        ├── D_improved/run-1、run-2、run-3/
        └── logs/
```

以上 `run-1、run-2、run-3` 表示三个独立的子目录，实际目录名分别为 `run-1/`、`run-2/`、`run-3/`。

## 数据来源与轮次

| 数据 | 来源 | 正式请求数 |
|---|---|---:|
| target1/shared_prefix | 第二次挑战已完成的共享前缀实验，原样归入任务书列出的 target1 | 32 |
| target1/dispersed_prefix | 第二次挑战已完成的分散前缀实验，原样归入任务书列出的 target1 | 32 |
| target3 的 A、B16、B64、C、D | 第三次挑战云端实验备份，五种配置各三轮 | 每轮 2048，共 30720 |

target1 是已有实验记录，不表示第三次挑战重新执行了这两组实验。target3 每轮另含 64 条预热记录，共 960 条。两类实验各自的指标口径以其原始配置与结果文件为准。

## 第三关结果与报告对应关系

| 报告配置 | results/target3 下的目录 | 路由与并发上限 |
|---|---|---|
| A | A_default/run-1 至 run-3 | P2C，5 |
| B16 | B_candidates/candidate-16/run-1 至 run-3 | P2C，16 |
| B64 | B_candidates/candidate-64/run-1 至 run-3 | P2C，64 |
| C | C_affinity/run-1 至 run-3 | consistent_hash，16 |
| D | D_improved/run-1 至 run-3 | affinity_overflow，16 |

报告三轮均值与每轮结果来自对应的 `summary.json`。主表后端分布为三个 `requests.csv` 的合计，共 6144 条；C 与 D 的逐轮分布对应各轮 summary 中的 backend_distribution。

每轮均保留以下四个文件，不能只提交 summary：

- `config.json`：实际命令、参数、负载校验与运行标识。
- `warmups.csv`：64 条预热请求的完整记录。
- `requests.csv`：2048 条正式请求的完整指标和路由头。
- `summary.json`：本轮成功率、吞吐量、缓存、Prefill、延迟与分布汇总。

`target3/logs/` 保留部署日志、SGLang 后端日志以及五份 Ray 拓扑快照，用于查验运行过程和节点状态。

## 整理校验

- target1：82 个文件；两组各 32 条正式请求和 32 份逐请求 JSON。
- target3：60 个实验文件，15 轮 × 4 个文件；另有 29 个日志及拓扑文件。
- 所有复制文件的 SHA256 与来源一致。
- 第三关 15 轮 CSV 行数、完整响应、token 汇总和后端分布与 summary 一致；无失败或不完整请求。
- 详细文件清单和校验记录保存在工作目录的 `hw3-results-file-manifest.json` 中；GPU 环境、安装、启动、回放和表格对应关系见[提交根目录 README](../README.md)。
