# 第三次挑战：四后端路由策略实验

本目录保存 A、B16、B64、C、D 五种配置各三轮的真实实验结果，以及部署、回放和统计脚本。每轮包含 64 条预热请求和 2048 条正式请求；15 轮共 30720 条正式请求，均成功且完整返回。实验报告为 `report.docx`，AI 使用说明为 `AI使用说明情况（第三次挑战）.docx`，按当前要求保留 Word 格式。

以下 GPU 服务命令在 **Linux 云端服务器**执行，从本提交根目录 `HW3-102501421/` 开始。Windows 本机用于保存材料。提交的 `results/` 为原始归档；复跑写入 `replay-results/`，避免覆盖原始数据。

## 1. 目录与脚本用途

```text
HW3-102501421/
├── README.md
├── report.docx
├── AI使用说明情况（第三次挑战）.docx
├── src/
│   ├── target1/prefix_benchmark.py
│   └── target3/
│       ├── deploy_a.py
│       ├── deploy_c.py
│       ├── deploy_d.py
│       ├── run_workload.py
│       ├── validate_workload.py
│       ├── compare_runs.py
│       ├── requirements.txt
│       ├── course_sources.json
│       └── mooncake_prefix_workload_v2_seed2026.jsonl
└── results/
    ├── README.md
    ├── target1/{shared_prefix,dispersed_prefix}/
    └── target3/
        ├── A_default/run-{1,2,3}/
        ├── B_candidates/candidate-16/run-{1,2,3}/
        ├── B_candidates/candidate-64/run-{1,2,3}/
        ├── C_affinity/run-{1,2,3}/
        ├── D_improved/run-{1,2,3}/
        └── logs/
```

上图的花括号是目录简写，实际分别有 `run-1/`、`run-2/`、`run-3/`。

| 脚本或文件 | 用途 |
|---|---|
| `src/target1/prefix_benchmark.py` | 第二关共享/分散前缀对照：构造 token 输入、清缓存、预热、测量、保存逐请求 JSON 和汇总。 |
| `src/target3/deploy_a.py` | 创建 1 head + 4 worker 的 Ray 集群及四个 BackendProxy；使用默认 P2C，通过参数运行 A、B16、B64。 |
| `src/target3/deploy_c.py` | C：100 个虚拟节点的一致性哈希，严格会话亲和，`num_fallback_replicas=0`。 |
| `src/target3/deploy_d.py` | D：优先亲和主 Replica；达到并发容量后尝试其他 Replica，由 Ray 当前负载观测选择较空闲者。 |
| `src/target3/run_workload.py` | 按固定到达时间回放预热及正式请求，解析 SSE、检查完整性和路由响应头，输出四个实验文件；不负责启动服务或清缓存。 |
| `src/target3/validate_workload.py` | 检查固定负载 SHA256、64 个前缀族、64 条预热、2048 条正式请求和到达计划。 |
| `src/target3/compare_runs.py` | 检查多轮汇总的可比性并计算均值、最小值、最大值和相对基线变化。 |
| `src/target3/requirements.txt` | 课程回放工具的依赖，仅包含 aiohttp；不是完整 GPU 服务环境清单。 |
| `src/target3/course_sources.json` | 课程工具下载来源、日期和文件 SHA256。 |

部署与前缀实验脚本来自本次保留的本地/云端文件。课程工具于 2026-10-06 从[课程公开仓库](https://github.com/Zirkland/26fall-HW-data/tree/main/workloads/hw2/target3-routing-policies)补齐，未改写。固定负载的 SHA256 与全部原实验一致；云端工具的 Git commit 未记录，因此不声明工具源码与当时云端版本逐字相同。

## 2. GPU、软件与服务配置

| 项目 | 实验记录 |
|---|---|
| 平台 | AutoDL Linux，同一容器实例；四块 GPU 在同一台服务器可见 |
| GPU | 4 × NVIDIA GeForce RTX 4090，每块约 24 GB（24564 MiB） |
| NVIDIA 驱动 | 580.76.05 |
| Python | 3.10.8 |
| SGLang / Ray | 0.5.14 / 2.56.0 |
| PyTorch / Transformers / aiohttp | 2.11.0 / 5.8.1 / 3.14.3 |
| Protobuf | 6.33.5（修复 Ray 与 Protobuf 7 的描述符接口冲突） |
| gRPC 相关 | grpcio 1.84.0；grpcio-health-checking、grpcio-reflection 使用 1.81.1 |
| mmh3 | 一致性哈希路由所需，已安装；未保留精确版本 |
| 模型 | Qwen/Qwen3-0.6B；本地目录 `/root/autodl-tmp/models/Qwen3-0.6B` |
| CUDA 工具包 | 数据盘目录 `/root/autodl-tmp/cuda13`，CUDA 13 工具链 |
| 四个 SGLang 后端 | GPU 0～3 对应 `127.0.0.1:30000`～`:30003`，每进程 TP=1 |
| 统一后端参数 | context=4096、mem-fraction-static=0.5、chunked-prefill-size=2048、stream-interval=1；Radix Cache 与 overlap 调度开启 |
| Ray / Serve | 1 head + 4 worker 为同机的五个逻辑节点；四个 Replica，每 worker 一个，Serve HTTP 为 `127.0.0.1:8000` |

GPU/驱动与基础软件版本依据 `results/target1/nvidia-smi.txt`、`config.json`、`server_info.json`，第三关复用原虚拟环境；Ray 与 Protobuf 调整另有当时终端记录。第三关后端参数和拓扑见 `results/target3/logs/`。未保存最终完整 `pip freeze`，上述列表不是所有间接依赖的锁文件。`nvidia-smi` 的 CUDA Version 表示驱动支持能力，工具链和 PyTorch 构建还需分别检查。

Ray worker 本身设置 `num_gpus=0`，GPU 由四个独立 SGLang 进程占用；worker 的 `backend_0`～`backend_3` 自定义资源保证 Replica 固定访问对应后端。这里的四 worker 不表示四台物理机器。

## 3. 安装与准备

### 3.1 复用原环境

```bash
source /root/autodl-tmp/first-challenge/.venv/bin/activate
export CUDA_HOME=/root/autodl-tmp/cuda13
export CUDA_PATH="$CUDA_HOME"
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$CUDA_HOME/lib:$CUDA_HOME/targets/x86_64-linux/lib:${LD_LIBRARY_PATH:-}"
export LIBRARY_PATH="$CUDA_HOME/targets/x86_64-linux/lib/stubs:${LIBRARY_PATH:-}"
mkdir -p replay-logs replay-results
```

### 3.2 新环境安装参考

机器应已安装可用 NVIDIA 驱动。若基础镜像的 CUDA 编译器不匹配，可按原实验方式安装数据盘工具链：

```bash
conda create -y -p /root/autodl-tmp/cuda13 \
  -c nvidia/label/cuda-13.0.0 cuda-toolkit
python3.10 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install \
  'sglang==0.5.14' 'ray[serve]==2.56.0' 'torch==2.11.0' \
  'transformers==5.8.1' 'aiohttp==3.14.3' 'mmh3' \
  'protobuf==6.33.5' 'grpcio==1.84.0' \
  'grpcio-health-checking==1.81.1' 'grpcio-reflection==1.81.1'
python -m pip check
```

然后设置 3.1 的 CUDA 环境变量。此命令锁定已知主要版本，没有锁定全部间接依赖或指定 PyTorch wheel 的 CUDA 构建；应检查以下输出与驱动、FlashInfer 的兼容性。该新环境安装流程未在另一台 GPU 机器重验。

```bash
nvidia-smi -L
nvcc --version
python - <<'PY'
import sys, torch, ray, google.protobuf
from google.protobuf.descriptor_pb2 import FileDescriptorProto
print('Python:', sys.version, sys.executable)
print('Torch:', torch.__version__, 'CUDA:', torch.version.cuda)
print('Visible GPUs:', torch.cuda.device_count())
print('Ray:', ray.__version__, 'Protobuf:', google.protobuf.__version__)
print('Descriptor.label:', hasattr(FileDescriptorProto.DESCRIPTOR.fields[0], 'label'))
PY
```

四块 GPU 应同时可见。Ray 2.56.0 在本次路径中使用 `FieldDescriptor.label`，检查应为 True；不要直接升级为此前报错的 Protobuf 7.36.2，也不要降级 gRPC health/reflection 为 1.76.0（会与 smg-grpc-servicer 的版本要求冲突）。

模型已下载时直接复用本地目录。缺少权重时可用 Hugging Face 下载，再启动后端：

```bash
python -m pip install huggingface_hub
hf download Qwen/Qwen3-0.6B --local-dir /root/autodl-tmp/models/Qwen3-0.6B
```

公开模型下载需要可访问模型仓库；模型、环境和 CUDA 安装目录不包含在本提交材料中。

## 4. 启动后端和 Ray Serve

### 4.1 启动四个独立后端

仅在没有运行相应后端时执行以下命令；已运行时先检查端口，避免重复启动。

```bash
mkdir -p replay-logs
for gpu in 0 1 2 3; do
  port=$((30000 + gpu))
  nohup env CUDA_VISIBLE_DEVICES="$gpu" python -m sglang.launch_server \
    --model-path /root/autodl-tmp/models/Qwen3-0.6B \
    --served-model-name Qwen/Qwen3-0.6B \
    --host 127.0.0.1 --port "$port" \
    --context-length 4096 --mem-fraction-static 0.5 \
    --chunked-prefill-size 2048 --stream-interval 1 \
    > "replay-logs/sglang-$gpu.log" 2>&1 &
  echo $! > "replay-logs/sglang-$gpu.pid"
done
```

等模型加载及 CUDA Graph 初始化完成，四个端口全部返回模型列表后继续：

```bash
for port in 30000 30001 30002 30003; do
  curl --fail --max-time 10 -sS "http://127.0.0.1:$port/v1/models" || break
  echo
done
```

任何端口报错时先查看对应 `replay-logs/sglang-*.log`；Ray 返回 READY 不代表后端可用。

### 4.2 启动当前配置（终端一）

每次只运行下列一条。切换配置或进入下一轮前，在原部署终端按 Ctrl+C，让脚本关闭自己的 Serve 与 Ray 集群；四个 SGLang 后端保持运行。管道启用 `pipefail`，避免 `tee` 隐藏部署退出码。

```bash
set -o pipefail
ROUND=1  # 第二、三轮分别改为 2、3，保存对应轮次日志
# A：默认 P2C，5
python src/target3/deploy_a.py --max-ongoing-requests 5 --run-label A 2>&1 | tee "replay-logs/ray-A-run-$ROUND.log"
# B16：P2C，16
python src/target3/deploy_a.py --max-ongoing-requests 16 --run-label B1 2>&1 | tee "replay-logs/ray-B16-run-$ROUND.log"
# B64：P2C，64
python src/target3/deploy_a.py --max-ongoing-requests 64 --run-label B2 2>&1 | tee "replay-logs/ray-B64-run-$ROUND.log"
# C：严格亲和，16
python src/target3/deploy_c.py --max-ongoing-requests 16 --run-label C 2>&1 | tee "replay-logs/ray-C-run-$ROUND.log"
# D：亲和溢出，16
python src/target3/deploy_d.py --max-ongoing-requests 16 --run-label D 2>&1 | tee "replay-logs/ray-D-run-$ROUND.log"
```

部署脚本按原实现写入 `logs/ray-topology-*.json`，不会写入归档的 `results/target3/logs/`。同标签后续启动会覆盖该工作快照，因此每轮另行备份（见第 5 节）。部署成功应有 `READY` 输出。可在终端二检查一次流式请求：

```bash
curl --fail --max-time 60 -i -N http://127.0.0.1:8000/generate \
  -H 'Content-Type: application/json' \
  -H 'X-Session-Id: smoke' -H 'X-Prefix-Family: smoke' \
  -H 'X-Workload-Request-ID: smoke-1' \
  -d '{"text":"Hello","sampling_params":{"temperature":0,"max_new_tokens":8,"ignore_eos":true},"stream":true}'
```

应返回 HTTP 200、SSE 数据及结束标记，带 `X-Ray-Replica-ID`、`X-Ray-Node-ID`、`X-SGLang-Backend` 响应头。502 且后端连接被拒绝表示该 SGLang 进程尚未可用。

## 5. 清缓存与回放（终端二）

终端二同样激活虚拟环境并进入提交根目录。正式测量前确认上次请求已结束，每轮重新部署 Serve、清空全部四个后端缓存；包括 smoke 请求产生的缓存也应清除。以下函数在该终端定义一次，随后按配置调用。不要更改发布负载的请求顺序、到达时间或 token 参数。

```bash
python src/target3/validate_workload.py src/target3/mooncake_prefix_workload_v2_seed2026.jsonl

replay_one() {
  local variant="$1" round="$2" group router capacity run_name label
  local -a extra=()
  case "$variant" in
    A)   group=A_default; router=p2c; capacity=5; run_name=A_default; label=A ;;
    B16) group=B_candidates/candidate-16; router=p2c; capacity=16; run_name=B_candidate16; label=B1 ;;
    B64) group=B_candidates/candidate-64; router=p2c; capacity=64; run_name=B_candidate64; label=B2 ;;
    C)   group=C_affinity; router=consistent_hash; capacity=16; run_name=C_affinity; label=C ;;
    D)   group=D_improved; router=affinity_overflow; capacity=16; run_name=D_improved; label=D
         extra=(--metadata overflow_threshold=16 --metadata fallback_rule=least_loaded_other_replicas) ;;
    *) echo '配置必须为 A/B16/B64/C/D'; return 1 ;;
  esac
  case "$round" in 1|2|3) ;; *) echo '轮次必须为 1/2/3'; return 1 ;; esac
  # 只在上一轮请求已全部结束后清缓存。
  python - <<'PY' || return 1
from urllib.request import Request, urlopen
for port in range(30000, 30004):
    request = Request(f'http://127.0.0.1:{port}/flush_cache?timeout=30', method='POST')
    with urlopen(request, timeout=60) as response:
        body = response.read().decode()
        if response.status != 200 or 'Cache flushed.' not in body:
            raise RuntimeError(f'Flush failed on {port}: {body}')
        print(port, body.strip())
PY
  mkdir -p "replay-logs/$variant/run-$round"
  cp "logs/ray-topology-$label.json" "replay-logs/$variant/run-$round/" || return 1
  python src/target3/run_workload.py \
    --policy serve --run-name "${run_name}_run${round}" \
    --router-name "$router" --max-ongoing-requests "$capacity" \
    --base-url http://127.0.0.1:8000 \
    --workload src/target3/mooncake_prefix_workload_v2_seed2026.jsonl \
    --max-in-flight 2048 "${extra[@]}" \
    --output-dir "replay-results/target3/$group/run-$round"
}
```

第一次按 A → B16 → B64 → C → D 执行，每个调用前先在终端一启动对应配置：

```bash
replay_one A 1
# Ctrl+C 停止 A，重新部署 B16 并等 READY 后：
replay_one B16 1
# 重新部署 B64：
replay_one B64 1
# 重新部署 C：
replay_one C 1
# 重新部署 D：
replay_one D 1
```

第二、三轮将轮次改为 2、3，仍逐次重新部署并清缓存，不直接连跑三次。`--router-name`、`--max-ongoing-requests`、D 的 `--metadata` 是回放记录参数，不能替代部署配置；两终端必须匹配。脚本默认拒绝覆盖已有结果，不使用 `--overwrite`。新一批复跑应使用新的输出根目录。

结束后立刻执行 `echo "实验退出码：$?"`，应为 0，并检查 `summary.json`：`successful=2048`、`failed=0`、`incomplete=0`、`warmup_successful=64`、`validation_errors=[]`，四个 backend/Replica/worker 均有请求。预热失败时可能产生 `failure.json` 并提前退出，这类运行不能替代成功的正式轮次。

## 6. 多轮统计命令

下面从已提交的原始汇总生成一个新的比较文件，不运行 GPU 服务、不修改原始结果。需安装回放工具的 aiohttp 才能回放；此比较脚本只使用 Python 标准库。

```bash
compare_args=()
for round in 1 2 3; do
  compare_args+=(--run "A=results/target3/A_default/run-$round/summary.json")
  compare_args+=(--run "B16=results/target3/B_candidates/candidate-16/run-$round/summary.json")
  compare_args+=(--run "B64=results/target3/B_candidates/candidate-64/run-$round/summary.json")
  compare_args+=(--run "C=results/target3/C_affinity/run-$round/summary.json")
  compare_args+=(--run "D=results/target3/D_improved/run-$round/summary.json")
done
python src/target3/compare_runs.py --baseline A --min-repeats 3 \
  "${compare_args[@]}" --output replay-results/comparison.json
```

对复跑数据统计时，将上述输入路径的 `results/target3/` 改为 `replay-results/target3/`。比较脚本的 JSON 用于核对报告指标；报告主表后端合计和排版需按下面口径读取原始文件。

## 7. 结果目录与报告表格对应关系

| 报告配置 | 原始结果目录（每个包含 run-1～run-3） | 路由 / max_ongoing_requests |
|---|---|---|
| A | `results/target3/A_default/` | P2C / 5 |
| B16（B 中选定值） | `results/target3/B_candidates/candidate-16/` | P2C / 16 |
| B64 | `results/target3/B_candidates/candidate-64/` | P2C / 64 |
| C | `results/target3/C_affinity/` | 严格一致性哈希 / 16 |
| D | `results/target3/D_improved/` | 亲和优先、容量溢出 / 16 |

| `report.docx` 的表格或内容 | 数据来源与计算口径 |
|---|---|
| 表 1：三轮平均结果 | 各配置三份 `summary.json` 的对应指标取算术平均；成功率为 successful/requests × 100%，缓存命中率乘 100 转为百分比。 |
| 表 1 续：四个 SGLang 后端请求分布 | 三份 `requests.csv` 按 backend 计数后相加，也可核对三份 summary 的 `backend_distribution`；每行总数 6144，仅正式请求。 |
| 表 2：C 与 D 每轮后端请求数 | C、D 各轮 summary 的 `backend_distribution`，每轮总数 2048，按端口 30000～30003 排列。 |
| 表 3：每轮主要指标 | 五种配置 × 三轮，各自 summary 的吞吐量、缓存命中率、实际 Prefill、TTFT p95、E2E p95，不先跨轮合并请求。 |
| 突发阶段、热点与排队分析 | `requests.csv` 的 traffic_phase、prefix_family、延迟和 backend；dispatch_lag、client_queue 仅辅助确认压测端是否成为瓶颈。 |
| 拓扑和四个独立后端验证 | `results/target3/logs/ray-topology-*.json`、部署/后端日志，以及 requests.csv 的 replica_id、ray_node_id、backend 一一映射。 |

关键汇总字段：

| 表中指标 | summary.json 字段 | 单位或说明 |
|---|---|---|
| 吞吐量 | `throughput_rps` | req/s，成功请求数除以含尾部排空的实际测量时长；不同于计划到达速率 offered_rate_rps。 |
| 缓存命中率 | `cache_hit_rate` | cached_tokens_total / prompt_tokens_total，按 token 加权；不是“命中请求数占比”。 |
| 实际 Prefill token | `computed_prefill_tokens_total` | 本轮 prompt_tokens_total − cached_tokens_total，总量；三轮均值可能不是整数，表中四舍五入。 |
| TTFT p95 | `ttft_s.p95` | 秒，首次返回 token 的延迟。 |
| 端到端延迟 p95 | `latency_s.p95` | 秒，请求完整返回的延迟。 |
| 后端分布 | `backend_distribution` | 正式请求计数；预热记录单独保存在 warmups.csv。 |

表 1 的延迟是“三个单轮 p95 的均值”，不是把 6144 条请求混在一起重新计算的 p95；结果波动见表 3及正文逐轮说明。每个正式轮的总输入为 3233280 token，各配置一致。

每个 `run-N/` 应保留四个文件：`config.json`（实际参数、命令和运行标识）、`warmups.csv`（64 条预热）、`requests.csv`（2048 条正式请求）、`summary.json`（汇总及校验）。只保存 summary 无法核对完整返回和路由分布。`results/README.md` 提供完整数据归档索引。

`results/target1/` 是第二次挑战的历史实验数据，两组各 32 条正式请求，原样复制以符合任务书的 target1 目录结构；本次没有重新执行 target1。它不进入第三关报告的表 1～3，不能混入上述三轮统计。target1 延迟字段以原始文件为准，其 CSV 使用毫秒口径，不能直接与 target3 的秒相混。

## 8. target1 的配套复跑方法与检查范围

若需重做共享/分散前缀对照，可复用已启动的 30000 后端：

```bash
python src/target1/prefix_benchmark.py \
  --base http://127.0.0.1:30000 \
  --model /root/autodl-tmp/models/Qwen3-0.6B \
  --results replay-results/target1
```

脚本自动建立带时间戳的运行子目录，先分散前缀、后共享前缀，每组清缓存，共享组另做前缀预热。每组 32 条正式请求、并发 8，每请求 2112 输入 token、16 输出 token；与 target3 发布负载是两种不同实验。

本次整理已检查：原始归档与备份 SHA256 一致；15 轮请求数、完整性、token 汇总及后端分布与 summary 一致；五份拓扑记录均为 1 head + 4 活跃 worker。README 配套源码进行了语法检查，固定负载通过课程校验工具，多轮汇总通过课程比较工具。云平台已结束实验，整理阶段未重新执行 GPU 部署或重建完整环境，因此不将静态检查称为新的 GPU 实验。
